import numpy as np
import pickle


if __name__ == "__main__":
    for game in ["bait", "labyrinth", "labyrinthdual", "waterpuzzle"]:
        with open(f"bfs_agent_symmetry_trained\\{game}\\results.txt", "rb") as file:
            results = pickle.load(file)

        for level in results:
            level_results = results[level]
            print(game, level, np.mean([level_results[run][2] == 3 for run in level_results]), np.mean([y[1] for x, y in level_results.items()]))

    for game in ["treasurekeeper", "zelda", "sokoban", "boulderdash", "golddigger"]:
        with open(f"rhea_agent_symmetry_trained\\{game}\\results.txt", "rb") as file:
            results = pickle.load(file)

        for level in results:
            level_results = results[level]
            print(game, level, np.mean([level_results[run][2] == 3 for run in level_results]), "/",
                  np.mean([y[1] for x, y in level_results.items()]))
