import numpy as np
import pickle


if __name__ == "__main__":
    results = dict()
    with open(f"results.txt", "r") as file:
        for line in file.readlines():
            if line.startswith("evaluate game "):
                current_game = line.split(" game ")[1][:-1]
                if current_game not in results:
                    results[current_game] = dict()
                continue

            if line.startswith("evaluate agent "):
                current_agent = line.split(" agent ")[1][:-1]
                if current_agent not in results[current_game]:
                    results[current_game][current_agent] = dict()
                continue

            if line.startswith("play level "):
                current_level = line.split(" level ")[1][:-1]
                if current_level not in results[current_game][current_agent]:
                    results[current_game][current_agent][current_level] = dict()
                    results[current_game][current_agent][current_level]["score"] = []
                    results[current_game][current_agent][current_level]["win"] = []
                continue

            if line.startswith("Result (1->win; 0->lose):"):
                score = float(line.split("Player0-Score:")[1].split(",")[0])
                win = float(line.split("Result (1->win; 0->lose): Player0:")[1].split(",")[0])

                if score <= -900:
                    print("ignore", current_game, current_agent, current_level, score)
                    continue
                results[current_game][current_agent][current_level]["score"].append(score)
                results[current_game][current_agent][current_level]["win"].append(win)

    for game in results:
            for level in results[game]["tracks.singlePlayer.simple.sampleRandom.Agent"]:
                print(f"{game} & {level} &   & " + " & ".join([
                    str(np.mean(results[game][agent][level]["win"][:20])) + " / " + str(np.mean(results[game][agent][level]["score"][:20]))
                     for agent in ["tracks.singlePlayer.advanced.sampleRS.Agent",
                      "tracks.singlePlayer.advanced.sampleRHEA.Agent",
                      "tracks.singlePlayer.advanced.sampleMCTS.Agent",
                      "tracks.singlePlayer.advanced.olets.Agent",
                      "tracks.singlePlayer.simple.sampleRandom.Agent"]]) + "\\\\")
            print()

    print("#######")




#        for level in results:
#            level_results = results[level]
#            print(game, level, np.mean([y[1] for x, y in level_results.items()]))
